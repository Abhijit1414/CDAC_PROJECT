import React from 'react'

const AdminPrivateRoute = () => {
  return (
    <div>AdminPrivateRoute</div>
  )
}

export default AdminPrivateRoute