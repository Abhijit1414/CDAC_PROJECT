import React from 'react'

const PageLoading = () => {
  return (
    <div>PageLoading</div>
  )
}

export default PageLoading