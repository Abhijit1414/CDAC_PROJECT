import React from 'react';

const Navbar = ({
  scrollToHome,
  scrollToWhyUs,
  scrollToHowItWorks,
  scrollToAbout,
  scrollToContact,
  scrollToOrder
}) => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light sticky-top">
      <div className="container-fluid">
        <span className="navbar-brand" onClick={scrollToHome}>
          Farmers Marketplace
        </span>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <span className="nav-link" onClick={scrollToHome}>Home</span>
            </li>
            <li className="nav-item">
              <span className="nav-link" onClick={scrollToWhyUs}>Why Us</span>
            </li>
            <li className="nav-item">
              <span className="nav-link" onClick={scrollToHowItWorks}>How It Works</span>
            </li>
            <li className="nav-item">
              <span className="nav-link" onClick={scrollToAbout}>About Us</span>
            </li>
            <li className="nav-item">
              <span className="nav-link" onClick={scrollToContact}>Contact</span>
            </li>
            <li className="nav-item">
              <span className="nav-link" onClick={scrollToOrder}>Order Now</span>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
