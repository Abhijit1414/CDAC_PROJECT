import React from 'react'

const UserPrivateRoute = () => {
  return (
    <div>UserPrivateRoute</div>
  )
}

export default UserPrivateRoute