import React, { useRef } from 'react';
import Navbar from './Navbar';  // Ensure you have Navbar imported here
import Footer from './Footer';  // Ensure you have Footer imported

const Homepage = () => {
  // Refs for each section to scroll to them
  const homeRef = useRef(null);
  const whyUsRef = useRef(null);
  const howItWorksRef = useRef(null);
  const aboutRef = useRef(null);
  const contactRef = useRef(null);
  const orderRef = useRef(null);

  return (
    <div className="homepage">
      <Navbar 
        scrollToHome={() => homeRef.current.scrollIntoView({ behavior: 'smooth' })}
        scrollToWhyUs={() => whyUsRef.current.scrollIntoView({ behavior: 'smooth' })}
        scrollToHowItWorks={() => howItWorksRef.current.scrollIntoView({ behavior: 'smooth' })}
        scrollToAbout={() => aboutRef.current.scrollIntoView({ behavior: 'smooth' })}
        scrollToContact={() => contactRef.current.scrollIntoView({ behavior: 'smooth' })}
        scrollToOrder={() => orderRef.current.scrollIntoView({ behavior: 'smooth' })}
      />
      
      {/* Home Section */}
      <div
        className="home-section"
        ref={homeRef}
      >
        <div className="home-content">
          <h1>Fresh Fruits & Vegetables</h1>
          <p>Directly from Farmers to Your Doorstep</p>
          <button className="btn-order" onClick={() => orderRef.current.scrollIntoView({ behavior: 'smooth' })}>
            Order Now
          </button>
        </div>
      </div>

      {/* Why Us Section */}
      <section
        className="section why-us"
        ref={whyUsRef}
      >
        <div className="section-content">
          <h2>Why Choose Us?</h2>
          <p>
            We provide high-quality, fresh fruits and vegetables that are sourced directly from local farmers.
            Our goal is to support sustainable agriculture and bring farm-fresh produce to your doorstep.
            You can trust us to deliver the best products while promoting local farmers and reducing food miles.
          </p>
        </div>
      </section>

      {/* How It Works Section */}
      <section
        className="section how-it-works"
        ref={howItWorksRef}
      >
        <div className="section-content">
          <h2>How It Works</h2>
          <p>
            Our process is simple and easy:
            <ol>
              <li>Browse our wide range of fresh fruits and vegetables.</li>
              <li>Add your items to your cart and check out.</li>
              <li>We deliver the products right to your doorstep, directly from the farm.</li>
            </ol>
            Enjoy fresh produce without the hassle!
          </p>
        </div>
      </section>

      {/* About Us Section */}
      <section
        className="section about-us"
        ref={aboutRef}
      >
        <div className="section-content">
          <h2>About Us</h2>
          <p>
            We are a marketplace designed to connect consumers with local farmers. Our platform enables
            you to buy the freshest produce directly from farmers in your region. By eliminating intermediaries,
            we ensure better prices for farmers and fresher produce for you.
          </p>
        </div>
      </section>

      {/* Contact Us Section */}
      <section
        className="section contact-us"
        ref={contactRef}
      >
        <div className="section-content">
          <h2>Contact Us</h2>
          <p>
            Have questions or feedback? Our team is here to help. Whether you're looking for more information
            about our products or need support with your order, don't hesitate to reach out to us.
          </p>
          <form>
            <div className="form-group">
              <label htmlFor="name">Your Name:</label>
              <input type="text" id="name" className="form-control" placeholder="Enter your name" />
            </div>
            <div className="form-group">
              <label htmlFor="email">Your Email:</label>
              <input type="email" id="email" className="form-control" placeholder="Enter your email" />
            </div>
            <div className="form-group">
              <label htmlFor="message">Your Message:</label>
              <textarea id="message" className="form-control" placeholder="Write your message here"></textarea>
            </div>
            <button type="submit" className="btn btn-primary">Send Message</button>
          </form>
        </div>
      </section>

      {/* Order Section */}
      <section
        className="section order"
        ref={orderRef}
      >
        <div className="section-content">
          <h2>Order Fresh Produce</h2>
          <p>Select your favorite fruits and vegetables and have them delivered to your doorstep!</p>
          <button className="btn-order">Start Ordering</button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Homepage;
