﻿using System.Collections.Generic;
using cultivatorscornerback.DAL;
using cultivatorscornerback.Models;

namespace cultivatorscornerback.Services
{
    public class FarmersServiceImpl : IFarmersService
    {
        private IFarmersDal _farmersDal;

        // Constructor to inject the dependency for IFarmersDal
        public FarmersServiceImpl(IFarmersDal farmersDal)
        {
            _farmersDal = farmersDal;
        }

        // Fetch a list of all farmers
        public List<Farmer> GetFarmersList()
        {
            return _farmersDal.GetAllFarmers();
        }

        // Fetch stock details for a specific farmer
        public List<StockDetails> GetFarmerStock(int farmerId)
        {
            return _farmersDal.GetFarmerStock(farmerId);
        }

        // Fetch details of a specific product for a farmer
        public StockDetails GetProductDetails(int farmerId, int productId)
        {
            return _farmersDal.GetProductDetails(farmerId, productId);
        }

        // Fetch details of a specific farmer
        public Farmer GetFarmerDetails(int id)
        {
            return _farmersDal.GetFarmerDetails(id);
        }

        // Fetch all products (stock) from all farmers
        public List<StockDetails> GetAllProduct()
        {
            return _farmersDal.GetAllProducts();
        }
    }
}
