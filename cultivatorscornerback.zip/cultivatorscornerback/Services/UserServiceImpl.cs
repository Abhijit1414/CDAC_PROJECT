﻿using System.Collections.Generic;

using cultivatorscornerback.DAL;
using cultivatorscornerback.Models;
using cultivatorscornerback.Services;

namespace cultivators_corner.Services
{
    public class UserServiceImpl : IUserService
    {
        private IUserDal _userDal;

        public UserServiceImpl(IUserDal userDal)
        {
            _userDal = userDal;
        }

        // Register a new user
        public bool Register(User user)
        {
            try
            {
                return _userDal.RegisterUser(user); // Return the success status of the registration
            }
            catch (Exception ex)
            {
                // Log the exception and return false or handle as needed
                return false;
            }
        }

        // Authenticate user with email and password
        public User Authenticate(string email, string password)
        {
            try
            {
                return _userDal.AuthenticateUser(email, password); // Returns the authenticated user or null
            }
            catch (Exception ex)
            {
                // Log the exception and return null or handle as needed
                return null;
            }
        }

        // Add a product to the cart
        public CartItem AddToCart(int productId, int qty)
        {
            try
            {
                return _userDal.AddToCart(productId, qty); // Return the added CartItem
            }
            catch (Exception ex)
            {
                // Log the exception and return null or handle as needed
                return null;
            }
        }

        // Place an order
        public bool PlaceOrder(Cart cart, User user)
        {
            try
            {
                return _userDal.PlaceOrder(cart, user); // Returns true or false based on the order placement success
            }
            catch (Exception ex)
            {
                // Log the exception and return false or handle as needed
                return false;
            }
        }

        // Get user details by userId
        public User GetUserDetails(int userId)
        {
            try
            {
                return _userDal.GetUserDetails(userId); // Fetch and return the user details
            }
            catch (Exception ex)
            {
                // Log the exception and return null or handle as needed
                return null;
            }
        }

        // Get all orders by userId
        public List<OrderDetails> GetOrder(int userId)
        {
            try
            {
                return _userDal.GetOrders(userId); // Fetch and return a list of orders for the user
            }
            catch (Exception ex)
            {
                // Log the exception and return an empty list or handle as needed
                return new List<OrderDetails>();
            }
        }
    }
}
