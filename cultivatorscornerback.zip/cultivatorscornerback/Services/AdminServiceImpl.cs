﻿using cultivatorscornerback.Custom_Exception;
using cultivatorscornerback.DAL;
using cultivatorscornerback.Models;
using Microsoft.EntityFrameworkCore;

using System.Collections.Generic;
using System.IO;

namespace cultivatorscornerback.Services
{
    public class AdminService : IAdminService
    {
        private readonly ApplicationDbContext _context;

        public AdminService(ApplicationDbContext context)
        {
            _context = context;
        }

        public bool AddFarmer(Farmer farmer)
        {
            try
            {
                _context.Farmers.Add(farmer);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool AddProduct(int farmerId, StockDetails product)
        {
            try
            {
                var farmer = _context.Farmers.Find(farmerId);
                if (farmer == null) return false;

                product.Farmer = farmer;
                _context.StockDetails.Add(product);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool RemoveFarmer(int farmerId)
        {
            try
            {
                var farmer = _context.Farmers.Include(f => f.Stock).FirstOrDefault(f => f.FarmerId == farmerId);
                if (farmer == null) return false;

                _context.StockDetails.RemoveRange(farmer.Stock);
                _context.Farmers.Remove(farmer);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool RemoveProduct(int productId)
        {
            try
            {
                var product = _context.StockDetails.Find(productId);
                if (product == null) return false;

                _context.StockDetails.Remove(product);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateProduct(StockDetails product)
        {
            try
            {
                _context.StockDetails.Update(product);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool UpdateFarmer(Farmer farmer)
        {
            try
            {
                _context.Farmers.Update(farmer);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public Farmer GetFarmerDetails(int farmerId)
        {
            return _context.Farmers.Find(farmerId);
        }

        public StockDetails GetProductDetails(int productId)
        {
            return _context.StockDetails.Find(productId);
        }

        public Category GetCategory(int categoryId)
        {
            return _context.Categories.Find(categoryId);
        }

        public bool SetCategory(string category)
        {
            var categoryEntity = new Category { CategoryName = category };
            _context.Categories.Add(categoryEntity);
            _context.SaveChanges();
            return true;
        }

        public bool RemoveCategory(int categoryId)
        {
            var category = _context.Categories.Find(categoryId);
            if (category != null)
            {
                _context.Categories.Remove(category);
                _context.SaveChanges();
                return true;
            }
            return false;
        }

        public string SaveImage(int productId, IFormFile imgFile)
        {
            try
            {
                var product = _context.StockDetails.Find(productId);
                if (product == null) return null;

                var path = Path.Combine("wwwroot/images", $"{productId}.jpg");
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    imgFile.CopyTo(stream);
                }

                product.ImagePath = path;
                _context.SaveChanges();
                return path;
            }
            catch
            {
                return null;
            }
        }

        public byte[] RestoreImage(int productId)
        {
            try
            {
                var product = _context.StockDetails.Find(productId);
                if (product?.ImagePath == null) return null;

                return File.ReadAllBytes(product.ImagePath);
            }
            catch
            {
                return null;
            }
        }

        public List<Category> GetAllCategories()
        {
            return _context.Categories.ToList();
        }

        public List<OrderDetails> GetAllOrders()
        {
            return _context.OrderDetails.Include(o => o.Orders).ToList();
        }

        public List<User> GetAllUsers()
        {
            return _context.Users.ToList();
        }

        public bool UpdateUser(User user)
        {
            try
            {
                _context.Users.Update(user);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public byte[] RestoreImageAgain(string productName)
        {
            var product = _context.StockDetails.FirstOrDefault(p => p.StockItem == productName);
            if (product?.ImagePath == null) throw new ResourceNotFoundException($"Image not yet assigned for {productName}");

            return File.ReadAllBytes(product.ImagePath);
        }
    }
}
