﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using cultivatorscornerback.Models;

namespace cultivatorscornerback.Services
{
    public interface IAdminService
    {
        bool AddFarmer(Farmer farmer);
        bool AddProduct(int farmerId, StockDetails product);
        bool RemoveFarmer(int farmerId);
        bool RemoveProduct(int productId);
        bool UpdateProduct(StockDetails product);
        bool UpdateFarmer(Farmer farmer);
        Farmer GetFarmerDetails(int farmerId);
        StockDetails GetProductDetails(int productId);
        Category GetCategory(int categoryId);
        bool SetCategory(string category);
        bool RemoveCategory(int categoryId);
        string SaveImage(int productId, IFormFile imgFile);
        byte[] RestoreImage(int productId);
        List<Category> GetAllCategories();
        List<OrderDetails> GetAllOrders();
        List<User> GetAllUsers();
        bool UpdateUser(User user);
        byte[] RestoreImageAgain(string productName);
    }
}
