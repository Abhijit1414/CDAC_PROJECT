﻿using System.Collections.Generic;
using cultivatorscornerback.Models;

namespace cultivatorscornerback.Services
{
    public interface IFarmersService
    {
        List<Farmer> GetFarmersList();
        Farmer GetFarmerDetails(int id);
        List<StockDetails> GetFarmerStock(int farmerId);
        StockDetails GetProductDetails(int farmerId, int productId);
        List<StockDetails> GetAllProduct();
    }
}
