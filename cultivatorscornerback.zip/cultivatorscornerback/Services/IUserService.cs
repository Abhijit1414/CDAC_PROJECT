﻿using cultivatorscornerback.Models;
using System.Collections.Generic;


namespace cultivatorscornerback.Services
{
    public interface IUserService
    {
        // Method to authenticate the user based on email and password
        User Authenticate(string email, string password);

        // Method to register a new user
        bool Register(User user);

        // Method to add a product to the cart
        CartItem AddToCart(int productId, int qty);

        // Method to place an order
        bool PlaceOrder(Cart cart, User user);

        // Method to fetch user details by user ID
        User GetUserDetails(int userId);

        // Method to get order details for a user
        List<OrderDetails> GetOrder(int userId);
    }
}
