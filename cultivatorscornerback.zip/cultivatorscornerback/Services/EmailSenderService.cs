﻿using System;
using System.Net;
using System.Net.Mail;
using System.IO;

namespace cultivatorscornerback.Services
{
    public class EmailSenderService
    {
        private string _smtpServer = "smtp.gmail.com"; // Use your SMTP server
        private int _smtpPort = 587; // Port number for Gmail SMTP
        private string _fromEmail = "your-email@gmail.com"; // Replace with your email
        private string _emailPassword = "your-email-password"; // Use App Password for Gmail if 2FA enabled

        public void SendSimpleEmail(string toEmail, string body, string subject)
        {
            try
            {
                var smtpClient = new SmtpClient(_smtpServer)
                {
                    Port = _smtpPort,
                    Credentials = new NetworkCredential(_fromEmail, _emailPassword),
                    EnableSsl = true
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_fromEmail),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };
                mailMessage.To.Add(toEmail);

                smtpClient.Send(mailMessage);
                Console.WriteLine("Mail Sent...");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending email: {ex.Message}");
            }
        }

        public void SendEmailWithAttachment(string toEmail, string body, string subject, string attachmentPath)
        {
            try
            {
                var smtpClient = new SmtpClient(_smtpServer)
                {
                    Port = _smtpPort,
                    Credentials = new NetworkCredential(_fromEmail, _emailPassword),
                    EnableSsl = true
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_fromEmail),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };
                mailMessage.To.Add(toEmail);

                // Add attachment
                if (!string.IsNullOrEmpty(attachmentPath) && File.Exists(attachmentPath))
                {
                    var attachment = new Attachment(attachmentPath);
                    mailMessage.Attachments.Add(attachment);
                }

                smtpClient.Send(mailMessage);
                Console.WriteLine("Mail with attachment Sent...");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending email with attachment: {ex.Message}");
            }
        }
    }
}
