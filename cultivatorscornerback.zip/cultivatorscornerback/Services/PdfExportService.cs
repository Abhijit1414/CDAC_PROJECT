﻿using System;
using System.Collections.Generic;
using System.IO;
using cultivatorscornerback.Models;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.draw;

namespace cultivatorscornerback.Services
{
    public class PdfExportService
    {
        public void Export(List<CartItem> items)
        {
            try
            {
                // Create a new document
                Document document = new Document();
                string filePath = "receipt.pdf"; // Path where the PDF will be saved
                PdfWriter.GetInstance(document, new FileStream(filePath, FileMode.Create));
                document.Open();

                // Add logo (ensure the file exists at this path)
                string logoPath = "fm.jpg"; // Update this with the actual path of your logo
                if (File.Exists(logoPath))
                {
                    Image logo = Image.GetInstance(logoPath);
                    logo.ScaleAbsolute(50, 50);
                    logo.Alignment = Element.ALIGN_LEFT;
                    document.Add(logo);
                }

                // Add title
                Font titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 20, BaseColor.BLACK);
                Paragraph title = new Paragraph("Cultivators Corner", titleFont)
                {
                    Alignment = Element.ALIGN_CENTER
                };
                document.Add(title);

                // Add a dotted line separator
                document.Add(new Chunk(new DottedLineSeparator()));

                // Create a table with 4 columns
                PdfPTable table = new PdfPTable(4);
                table.WidthPercentage = 100; // Set table width to 100%
                table.SetWidths(new float[] { 3f, 1f, 1f, 1f }); // Set column widths

                // Add header row
                AddTableHeader(table);

                // Add data rows
                AddRows(table, items);

                // Add table to document
                document.Add(table);

                // Calculate and display the grand total
                double grandTotal = 0.0;
                foreach (var item in items)
                {
                    grandTotal += item.Amount;
                }

                // Add total amount
                document.Add(new Chunk(Environment.NewLine)); // Add space
                Font totalFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14, BaseColor.BLACK);
                Paragraph totalParagraph = new Paragraph($"Total Amount: ${grandTotal:F2}", totalFont)
                {
                    Alignment = Element.ALIGN_RIGHT
                };
                document.Add(totalParagraph);

                // Close the document
                document.Close();

                Console.WriteLine("PDF generated successfully at: " + filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error generating PDF: {ex.Message}");
            }
        }

        private void AddTableHeader(PdfPTable table)
        {
            // Set the header titles
            string[] headers = { "Product Name", "Quantity", "Price", "Amount" };
            Font headerFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.WHITE);

            foreach (var header in headers)
            {
                PdfPCell headerCell = new PdfPCell(new Phrase(header, headerFont))
                {
                    BackgroundColor = BaseColor.DARK_GRAY,
                    HorizontalAlignment = Element.ALIGN_CENTER
                };
                table.AddCell(headerCell);
            }
        }

        private void AddRows(PdfPTable table, List<CartItem> items)
        {
            // Font for table rows
            Font rowFont = FontFactory.GetFont(FontFactory.HELVETICA, 11, BaseColor.BLACK);

            // Add rows to the table
            foreach (var item in items)
            {
                table.AddCell(new PdfPCell(new Phrase(item.Item, rowFont)) { HorizontalAlignment = Element.ALIGN_LEFT });
                table.AddCell(new PdfPCell(new Phrase(item.Qty.ToString(), rowFont)) { HorizontalAlignment = Element.ALIGN_CENTER });
                table.AddCell(new PdfPCell(new Phrase($"${item.Price:F2}", rowFont)) { HorizontalAlignment = Element.ALIGN_RIGHT });
                table.AddCell(new PdfPCell(new Phrase($"${item.Amount:F2}", rowFont)) { HorizontalAlignment = Element.ALIGN_RIGHT });
            }
        }
    }
}
