using cultivators_corner.DAL;
using cultivators_corner.Services;
using cultivatorscornerback.DAL;
using cultivatorscornerback.Services;
using Microsoft.EntityFrameworkCore;

namespace cultivatorscornerback
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
               options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
           );
            builder.Services.AddScoped<IAdminDal, AdminDal>();
            builder.Services.AddScoped<IFarmersDal, FarmersDal>();
            builder.Services.AddScoped<IUserDal, UserDal>();
            builder.Services.AddScoped<IFarmersService, FarmersServiceImpl>();
            builder.Services.AddScoped<IAdminService, AdminService>();
            builder.Services.AddScoped<IUserService, UserServiceImpl>();
            builder.Services.AddScoped<PdfExportService>();
            builder.Services.AddScoped<EmailSenderService>();



            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
