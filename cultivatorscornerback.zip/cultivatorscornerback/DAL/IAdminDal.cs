﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using cultivatorscornerback.Models;
using Microsoft.AspNetCore.Http;

namespace cultivatorscornerback.DAL
{
    public interface IAdminDal
    {
        bool AddFarmer(Farmer farmer);
        bool AddProduct(int farmerId, StockDetails product);
        bool RemoveFarmer(int farmerId);
        bool RemoveProduct(int productId);
        bool UpdateFarmer(Farmer farmer);
        bool UpdateProduct(StockDetails product);
        StockDetails GetProductDetails(int productId);
        Farmer GetFarmerDetails(int farmerId);
        Category GetCategory(int categoryId);
        bool SetCategory(string category);
        bool RemoveCategory(int categoryId);
        Task<string> SaveImageAsync(int productId, IFormFile imgFile);
        Task<byte[]> RestoreImageAsync(int productId);
        List<Category> GetAllCategories();
        List<OrderDetails> GetAllOrders();
        List<User> GetAllUsers();
        bool UpdateUser(User user);
    }
}
