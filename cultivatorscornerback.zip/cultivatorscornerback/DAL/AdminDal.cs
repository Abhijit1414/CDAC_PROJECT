﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using cultivatorscornerback.DAL;
using cultivatorscornerback.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace cultivatorscornerback.DAL
{
    public class AdminDal : IAdminDal
    {
        private ApplicationDbContext _context;
        private readonly ILogger<AdminDal> _logger;
        private IFarmersDal _farmersDal;

        public AdminDal(ApplicationDbContext context, ILogger<AdminDal> logger, IFarmersDal farmersDal)
        {
            _context = context;
            _logger = logger;
            _farmersDal = farmersDal;
        }

        public bool AddFarmer(Farmer farmer)
        {
            try
            {
                foreach (var product in farmer.Stock)
                {
                    product.Farmer = farmer;
                    _context.StockDetails.Add(product);
                }
                _context.Farmers.Add(farmer);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding farmer.");
                return false;
            }
        }

        public bool AddProduct(int farmerId, StockDetails product)
        {
            try
            {
                var farmer = _farmersDal.GetFarmerDetails(farmerId);
                if (farmer == null) return false;

                product.Farmer = farmer;
                _context.StockDetails.Add(product);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding product.");
                return false;
            }
        }

        public bool RemoveFarmer(int farmerId)
        {
            try
            {
                var farmer = _context.Farmers.Include(f => f.Stock).FirstOrDefault(f => f.FarmerId == farmerId);
                if (farmer == null) return false;

                _context.StockDetails.RemoveRange(farmer.Stock);
                _context.Farmers.Remove(farmer);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing farmer.");
                return false;
            }
        }

        public bool RemoveProduct(int productId)
        {
            try
            {
                var product = _context.StockDetails.Find(productId);
                if (product == null) return false;

                _context.StockDetails.Remove(product);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing product.");
                return false;
            }
        }

        public bool UpdateFarmer(Farmer farmer)
        {
            _context.Farmers.Update(farmer);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateProduct(StockDetails product)
        {
            _context.StockDetails.Update(product);
            return _context.SaveChanges() > 0;
        }

        public StockDetails GetProductDetails(int productId)
        {
            return _context.StockDetails.Find(productId);
        }

        public Farmer GetFarmerDetails(int farmerId)
        {
            return _context.Farmers.Find(farmerId);
        }

        public Category GetCategory(int categoryId)
        {
            return _context.Categories.Find(categoryId);
        }

        public bool SetCategory(string categoryName)
        {
            var category = new Category { CategoryName = categoryName };
            _context.Categories.Add(category);
            return _context.SaveChanges() > 0;
        }

        public bool RemoveCategory(int categoryId)
        {
            var category = _context.Categories.Find(categoryId);
            if (category != null)
            {
                _context.Categories.Remove(category);
                return _context.SaveChanges() > 0;
            }
            return false;
        }

        public async Task<string> SaveImageAsync(int productId, IFormFile imgFile)
        {
            try
            {
                var product = _context.StockDetails.Find(productId);
                if (product == null) return null;

                var path = Path.Combine("wwwroot/images", $"{productId}.jpg");
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    await imgFile.CopyToAsync(stream);
                }

                product.ImagePath = path;
                _context.SaveChanges();
                return path;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving image.");
                return null;
            }
        }

        public async Task<byte[]> RestoreImageAsync(int productId)
        {
            try
            {
                var product = _context.StockDetails.Find(productId);
                if (product?.ImagePath == null) return null;

                return await File.ReadAllBytesAsync(product.ImagePath);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error restoring image.");
                return null;
            }
        }

        public List<Category> GetAllCategories()
        {
            return _context.Categories.ToList();
        }

        public List<OrderDetails> GetAllOrders()
        {
            return _context.OrderDetails.Include(o => o.Orders).ToList();
        }

        public List<User> GetAllUsers()
        {
            return _context.Users.ToList();
        }

        public bool UpdateUser(User user)
        {
            _context.Users.Update(user);
            return _context.SaveChanges() > 0;
        }
    }
}
