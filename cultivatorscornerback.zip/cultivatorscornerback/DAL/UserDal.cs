﻿using System;
using System.Collections.Generic;
using System.Linq;

using cultivatorscornerback.DAL;
using cultivatorscornerback.Models;
using Microsoft.EntityFrameworkCore;

namespace cultivators_corner.DAL
{
    public class UserDal : IUserDal
    {
        private readonly ApplicationDbContext _context;

        public UserDal(ApplicationDbContext context)
        {
            _context = context;
        }

        public bool RegisterUser(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
            return true;
        }

        public User AuthenticateUser(string email, string password)
        {
            // Using ToLower() to ensure case-insensitive comparison
            var user = _context.Users
                .FirstOrDefault(u => u.Email.ToLower() == email.ToLower() && u.Password == password);

            if (user == null)
            {
                Console.WriteLine("User not found or invalid credentials.");
                return null;
            }

            Console.WriteLine($"User found: {user.Email}");
            return user;
        }

        public CartItem AddToCart(int productId, int qty)
        {
            var product = _context.StockDetails
                .Where(sd => sd.Id == productId)
                .Select(sd => new StockDetails
                {
                    Id = sd.Id,
                    StockItem = sd.StockItem,
                    PricePerUnit = sd.PricePerUnit
                }).FirstOrDefault();

            var farmer = _context.StockDetails
                .Where(sd => sd.Id == productId)
                .Select(sd => sd.Farmer)
                .FirstOrDefault();

            if (product == null || farmer == null)
                return null;

            return new CartItem
            {
                Id = product.Id,
                Item = product.StockItem,
                Price = (double)product.PricePerUnit,
                Qty = qty,
                Amount = (double)(qty * product.PricePerUnit),
                FarmerId = farmer.FarmerId
            };
        }

        public bool PlaceOrder(Cart cart, User user)
        {
            var order = new Orders
            {
                DeliveryStatus = false,
                PaymentStatus = true,
                User = user,
                PlaceOrderDate = DateTime.Now,
                DeliveryDate = DateTime.Now.AddDays(3),
                OrderDetails = new List<OrderDetails>()
            };

            foreach (var item in cart.Items)
            {
                var farmer = _context.Farmers.Find(item.FarmerId);
                if (farmer == null) continue;

                var details = new OrderDetails
                {
                    Amount = item.Amount,
                    OrderItem = item.Item,
                    Quantity = item.Qty,
                    Farmer = farmer,
                    Orders = order
                };

                order.OrderDetails.Add(details);
            }

            _context.Orders.Add(order);
            _context.SaveChanges();
            return true;
        }

        public User GetUserDetails(int userId)
        {
            return _context.Users
                .Where(u => u.UserId == userId)
                .Select(u => new User
                {
                    UserId = u.UserId,
                    Firstname = u.Firstname,
                    Lastname = u.Lastname,
                    Email = u.Email,
                    PhoneNo = u.PhoneNo,
                    Address = u.Address,
                    Password = u.Password
                }).FirstOrDefault();
        }

        public List<OrderDetails> GetOrders(int userId)
        {
            return _context.OrderDetails
                .Include(od => od.Orders)
                .Where(od => od.Orders.User.UserId == userId)
                .Select(od => new OrderDetails
                {
                    Id = od.Id,
                    OrderItem = od.OrderItem,
                    Quantity = od.Quantity,
                    Amount = od.Amount,
                    Orders = od.Orders
                }).ToList();
        }
    }
}
