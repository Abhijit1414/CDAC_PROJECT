﻿using cultivatorscornerback.Models;
using System.Collections.Generic;


namespace cultivatorscornerback.DAL
{
    public interface IUserDal
    {
        bool RegisterUser(User user);
        User AuthenticateUser(string email, string password);
        CartItem AddToCart(int productId, int quantity);
        bool PlaceOrder(Cart cart, User user);
        User GetUserDetails(int userId);
        List<OrderDetails> GetOrders(int userId);
    }
}
