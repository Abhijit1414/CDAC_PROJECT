﻿using System.Collections.Generic;
using System.Linq;

using cultivatorscornerback.DAL;
using cultivatorscornerback.Models;
using Microsoft.EntityFrameworkCore;

namespace cultivators_corner.DAL
{
    public class FarmersDal : IFarmersDal
    {
        private ApplicationDbContext _context;

        public FarmersDal(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<Farmer> GetAllFarmers()
        {
            return _context.Farmers
                .Select(f => new Farmer
                {
                    FarmerId = f.FarmerId,
                    Firstname = f.Firstname,
                    Lastname = f.Lastname,
                    Email = f.Email,
                    PhoneNo = f.PhoneNo,
                    Address = f.Address
                }).ToList();
        }

        public List<StockDetails> GetFarmerStock(int farmerId)
        {
            return _context.StockDetails
                .Where(sd => sd.Farmer.FarmerId == farmerId)
                .Select(sd => new StockDetails
                {
                    Id = sd.Id,
                    StockItem = sd.StockItem,
                    PricePerUnit = sd.PricePerUnit
                }).ToList();
        }

        public StockDetails GetProductDetails(int farmerId, int productId)
        {
            return _context.StockDetails
                .Where(sd => sd.Farmer.FarmerId == farmerId && sd.Id == productId)
                .Select(sd => new StockDetails
                {
                    Id = sd.Id,
                    StockItem = sd.StockItem,
                    Quantity = sd.Quantity,
                    PricePerUnit = sd.PricePerUnit,
                    Category = sd.Category
                }).FirstOrDefault();
        }

        public Farmer GetFarmerDetails(int id)
        {
            return _context.Farmers
                .Where(f => f.FarmerId == id)
                .Select(f => new Farmer
                {
                    FarmerId = f.FarmerId,
                    Firstname = f.Firstname,
                    Lastname = f.Lastname,
                    Email = f.Email,
                    PhoneNo = f.PhoneNo,
                    Address = f.Address
                }).FirstOrDefault();
        }

        public List<StockDetails> GetAllProducts()
        {
            return _context.StockDetails
                .Select(s => new StockDetails
                {
                    Id = s.Id,
                    StockItem = s.StockItem,
                    Quantity = s.Quantity,
                    PricePerUnit = s.PricePerUnit,
                    Category = s.Category,
                    ImagePath = s.ImagePath
                }).ToList();
        }
    }
}
