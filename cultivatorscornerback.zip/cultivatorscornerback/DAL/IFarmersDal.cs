﻿using System.Collections.Generic;
using cultivatorscornerback.Models;

namespace cultivatorscornerback.DAL
{
    public interface IFarmersDal
    {
        List<StockDetails> GetAllProducts();
        List<Farmer> GetAllFarmers();
        Farmer GetFarmerDetails(int id);
        List<StockDetails> GetFarmerStock(int farmerId);
        StockDetails GetProductDetails(int farmerId, int productId);
    }
}
