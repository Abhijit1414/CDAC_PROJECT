﻿using cultivatorscornerback.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace cultivatorscornerback.DAL
{
        public class ApplicationDbContext : DbContext
        {
            public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

            // Define DbSet properties for your entities
            public DbSet<User> Users { get; set; }
            public DbSet<Farmer> Farmers { get; set; }
            public DbSet<Category> Categories { get; set; }
            public DbSet<StockDetails> StockDetails { get; set; }
            public DbSet<Orders> Orders { get; set; }
            public DbSet<OrderDetails> OrderDetails { get; set; }
            public DbSet<CartItem> CartItems { get; set; }


        }
    }
