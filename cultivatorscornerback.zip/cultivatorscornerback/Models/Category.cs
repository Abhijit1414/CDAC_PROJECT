﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace cultivatorscornerback.Models
{
    [Table("category")]
    public class Category
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("category_id")]
        public int CategoryId { get; set; }

        [Required]
        [Column("category_name")]
        public string CategoryName { get; set; }

        [JsonIgnore] // Prevents infinite loops during JSON serialization
        public virtual List<StockDetails> StockDetails { get; set; } = new List<StockDetails>();

        // Constructors
        public Category() { }

        public Category(int categoryId, string categoryName)
        {
            CategoryId = categoryId;
            CategoryName = categoryName;
        }

        public Category(int categoryId)
        {
            CategoryId = categoryId;
        }

        public override string ToString()
        {
            return $"Category [CategoryId={CategoryId}, CategoryName={CategoryName}]";
        }
    }
}
