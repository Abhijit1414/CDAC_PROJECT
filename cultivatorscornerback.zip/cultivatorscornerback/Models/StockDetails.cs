﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace cultivatorscornerback.Models
{
    [Table("stock_details")]
    public class StockDetails
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("product_id")]
        public int Id { get; set; }

        [Required]
        [Column("stock_item")]
        [StringLength(50)]
        public string StockItem { get; set; }

        [Required]
        [Column("quantity")]
        public int Quantity { get; set; }

        [Column("price_per_unit", TypeName = "decimal(12,2)")]
        public float PricePerUnit { get; set; }

        [ForeignKey("Category")]
        [Column("category_id")]
        public int CategoryId { get; set; }

        [JsonIgnore]
        public virtual Category Category { get; set; }

        [ForeignKey("Farmer")]
        [Column("farmer_id")]
        public int FarmerId { get; set; }

        [JsonIgnore]
        public virtual Farmer Farmer { get; set; }

        [Column("product_image")]
        [StringLength(400)]
        public string ImagePath { get; set; }

        // Constructors
        public StockDetails() { }

        public StockDetails(int id, string stockItem, float pricePerUnit)
        {
            Id = id;
            StockItem = stockItem;
            PricePerUnit = pricePerUnit;
        }

        public StockDetails(int id, string stockItem, int quantity, float pricePerUnit, Category category)
        {
            Id = id;
            StockItem = stockItem;
            Quantity = quantity;
            PricePerUnit = pricePerUnit;
            Category = category;
        }

        public StockDetails(int id, string stockItem, int quantity, float pricePerUnit, Category category, string imagePath)
        {
            Id = id;
            StockItem = stockItem;
            Quantity = quantity;
            PricePerUnit = pricePerUnit;
            Category = category;
            ImagePath = imagePath;
        }

        public override string ToString()
        {
            return $"StockDetails [Id={Id}, StockItem={StockItem}, Quantity={Quantity}, PricePerUnit={PricePerUnit}, Category={Category?.CategoryName}, Farmer={Farmer?.FarmerId}, ImagePath={ImagePath}]";
        }
    }
}
