﻿namespace cultivatorscornerback.Models
{
    public class ApiResponse
    {
        public DateTime TimeStamp { get; set; }
        public string Message { get; set; }

        public ApiResponse(string message)
        {
            Message = message;
            TimeStamp = DateTime.UtcNow;
        }
    }
}
