﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace cultivatorscornerback.Models
{
    [Table("user")]
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("user_id")]
        public int UserId { get; set; }

        [Required]
        [EmailAddress]
        [Column("email")]
        [StringLength(50)]
        public string Email { get; set; }

        [Required]
        [Column("password")]
        [StringLength(30)]
        public string Password { get; set; }

        [Column("phone_no")]
        [StringLength(15)]
        public string PhoneNo { get; set; }

        [Column("Address")]
        [StringLength(200)]
        public string Address { get; set; }

        [Column("firstname")]
        [StringLength(20)]
        public string Firstname { get; set; }

        [Column("lastname")]
        [StringLength(20)]
        public string Lastname { get; set; }

        [Column("is_admin")]
        public bool IsAdmin { get; set; }

        [JsonIgnore] // Prevents infinite loops when serializing JSON
        public virtual List<Orders> Orders { get; set; } = new List<Orders>();

        // Constructors
        public User() { }

        public User(string email, string password)
        {
            Email = email;
            Password = password;
        }

        public User(string email, string password, string phoneNo, string address, string firstname, string lastname, bool isAdmin)
        {
            Email = email;
            Password = password;
            PhoneNo = phoneNo;
            Address = address;
            Firstname = firstname;
            Lastname = lastname;
            IsAdmin = isAdmin;
        }

        public User(int userId, string email, string password, string phoneNo, string address, string firstname, string lastname, bool isAdmin)
        {
            UserId = userId;
            Email = email;
            Password = password;
            PhoneNo = phoneNo;
            Address = address;
            Firstname = firstname;
            Lastname = lastname;
            IsAdmin = isAdmin;
        }

        public override string ToString()
        {
            return $"User [UserId={UserId}, Email={Email}, Password={Password}, PhoneNo={PhoneNo}, Address={Address}, Firstname={Firstname}, Lastname={Lastname}]";
        }
    }
}
