﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace cultivatorscornerback.Models
{
    [Table("order_details")]
    public class OrderDetails
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("id")]
        public int Id { get; set; }

        [Required]
        [Column("order_item")]
        [StringLength(20)]
        public string OrderItem { get; set; }

        [Required]
        [Column("quantity")]
        public int Quantity { get; set; }

        [Required]
        [Column("amount", TypeName = "decimal(18,2)")]
        public double Amount { get; set; }

        [ForeignKey("Farmer")]
        [Column("farmer_id")]
        public int? FarmerId { get; set; } // Nullable to match optional farmer relation

        [JsonIgnore]
        public virtual Farmer Farmer { get; set; }

        [ForeignKey("Orders")]
        [Column("order_id")]
        public int OrderId { get; set; }

        [JsonIgnore]
        public virtual Orders Orders { get; set; }

        // Constructors
        public OrderDetails() { }

        public OrderDetails(int id, string orderItem, int quantity, double amount, Orders orders)
        {
            Id = id;
            OrderItem = orderItem;
            Quantity = quantity;
            Amount = amount;
            Orders = orders;
            OrderId = orders.OrderId;
        }

        public override string ToString()
        {
            return $"OrderDetails [Id={Id}, OrderItem={OrderItem}, Quantity={Quantity}, Amount={Amount}, OrderId={OrderId}, FarmerId={FarmerId}]";
        }
    }
}
