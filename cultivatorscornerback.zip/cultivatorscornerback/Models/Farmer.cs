﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace cultivatorscornerback.Models
{
    [Table("farmer")]
    public class Farmer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("farmer_id")]
        public int FarmerId { get; set; }

        [Column("firstname")]
        [StringLength(20)]
        public string Firstname { get; set; }

        [Column("lastname")]
        [StringLength(20)]
        public string Lastname { get; set; }

        [Column("email")]
        [StringLength(50)]
        public string Email { get; set; }

        [Column("phone_no")]
        [StringLength(15)]
        public string PhoneNo { get; set; }

        [Column("address")]
        [StringLength(200)]
        public string Address { get; set; }

        [JsonIgnore]
        public virtual ICollection<OrderDetails> OrderDetails { get; set; } = new List<OrderDetails>();

        [JsonIgnore]
        public virtual ICollection<StockDetails> Stock { get; set; } = new List<StockDetails>();

        // Constructors
        public Farmer() { }

        public Farmer(int farmerId, string firstname, string lastname, string email, string phoneNo, string address)
        {
            FarmerId = farmerId;
            Firstname = firstname;
            Lastname = lastname;
            Email = email;
            PhoneNo = phoneNo;
            Address = address;
        }

        public Farmer(int farmerId, string firstname, string lastname)
        {
            FarmerId = farmerId;
            Firstname = firstname;
            Lastname = lastname;
        }

        public override string ToString()
        {
            return $"Farmer [FarmerId={FarmerId}, Firstname={Firstname}, Lastname={Lastname}, Email={Email}, PhoneNo={PhoneNo}, Address={Address}]";
        }
    }
}
