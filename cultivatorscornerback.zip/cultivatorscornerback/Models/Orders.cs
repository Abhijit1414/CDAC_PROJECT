﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace cultivatorscornerback.Models
{
    [Table("orders")]
    public class Orders
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("order_id")]
        public int OrderId { get; set; }

        [Column("payment_status")]
        public bool PaymentStatus { get; set; }

        [Column("delivery_status")]
        public bool DeliveryStatus { get; set; }

        [JsonIgnore] // Prevents circular references when serializing JSON
        public virtual List<OrderDetails> OrderDetails { get; set; } = new List<OrderDetails>();

        [ForeignKey("User")]
        [Column("user_id")]
        public int UserId { get; set; }

        public virtual User User { get; set; }

        [Column("place_order_date", TypeName = "date")]
        public DateTime? PlaceOrderDate { get; set; }

        [Column("delivery_date", TypeName = "date")]
        public DateTime? DeliveryDate { get; set; }

        // Constructors
        public Orders() { }

        public Orders(int orderId, bool paymentStatus, bool deliveryStatus, User user, DateTime? placeOrderDate, DateTime? deliveryDate)
        {
            OrderId = orderId;
            PaymentStatus = paymentStatus;
            DeliveryStatus = deliveryStatus;
            User = user;
            PlaceOrderDate = placeOrderDate;
            DeliveryDate = deliveryDate;
        }

        public override string ToString()
        {
            return $"Orders [OrderId={OrderId}, PaymentStatus={PaymentStatus}, DeliveryStatus={DeliveryStatus}, UserId={UserId}, PlaceOrderDate={PlaceOrderDate}, DeliveryDate={DeliveryDate}]";
        }
    }
}
