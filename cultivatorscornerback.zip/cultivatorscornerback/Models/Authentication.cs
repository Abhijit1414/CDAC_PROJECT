﻿namespace cultivatorscornerback.Models
{
    public class Authentication
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
