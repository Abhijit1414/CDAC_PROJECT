﻿namespace cultivatorscornerback.Models
{
    public class CartItem
    {
        public int Id { get; set; }
        public string Item { get; set; }
        public int Qty { get; set; }
        public double Price { get; set; }
        public double Amount { get; set; }
        public int FarmerId { get; set; }

        public CartItem()
        {
            Console.WriteLine("CartItem Constructor invoked");
        }

        public override string ToString()
        {
            return $"CartItem [Id={Id}, Item={Item}, Qty={Qty}, Price={Price}, Amount={Amount}]";
        }
    }
}
