﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using cultivatorscornerback.Services;

namespace cultivatorscornerback.Controllers
{
    [Route("api/farmer")]
    [ApiController]
    [Produces("application/json")]
    public class FarmerController : ControllerBase
    {
        private IFarmersService _farmerService;

        public FarmerController(IFarmersService farmerService)
        {
            _farmerService = farmerService;
        }

        [HttpGet("list")]
        public IActionResult GetFarmersList()
        {
            var list = _farmerService.GetFarmersList();
            return Ok(list);
        }

        [HttpGet("farmerdetails/{farmerid}")]
        public IActionResult GetFarmerDetails(int farmerid)
        {
            var farmer = _farmerService.GetFarmerDetails(farmerid);
            if (farmer == null)
                return NotFound();
            return Ok(farmer);
        }

        [HttpGet("products/{farmerid}")]
        public IActionResult GetFarmerStock(int farmerid)
        {
            var products = _farmerService.GetFarmerStock(farmerid);
            return Ok(products);
        }

        [HttpGet("products/{farmerid}/{productid}")]
        public IActionResult GetProductDetails(int farmerid, int productid)
        {
            var product = _farmerService.GetProductDetails(farmerid, productid);
            if (product == null)
                return NotFound();
            return Ok(product);
        }

        [HttpGet("allproducts")]
        public IActionResult GetAllProducts()
        {
            var list = _farmerService.GetAllProduct();
            return Ok(list);
        }
    }
}
