﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using cultivatorscornerback.Models;
using cultivatorscornerback.Services;
using System.Collections.Generic;
using cultivatorscornerback.Services;

namespace cultivators_corner.Controllers
{
    [Route("api/admin")]
    [ApiController]
    [Produces("application/json")]
    public class AdminController : ControllerBase
    {
        private IAdminService _service;
        private IFarmersService _farmerService;
        private IUserService _userService;

        public AdminController(IAdminService service, IFarmersService farmerService, IUserService userService)
        {
            _service = service;
            _farmerService = farmerService;
            _userService = userService;
        }

        [HttpPost("newfarmer")]
        public IActionResult AddNewFarmer([FromBody] Farmer farmer)
        {
            var result = _service.AddFarmer(farmer);
            if (!result)
                return BadRequest("Failed to add farmer.");
            return Ok(farmer);
        }

        [HttpPost("newproduct/{farmerid}")]
        public IActionResult AddNewProduct(int farmerid, [FromBody] StockDetails product)
        {
            var result = _service.AddProduct(farmerid, product);
            if (!result)
                return BadRequest("Failed to add product.");
            return Ok("Product Added Successfully");
        }

        [HttpPost("{productid}/image")]
        public IActionResult UploadImage(int productid, IFormFile imgFile)
        {
            if (imgFile == null || imgFile.Length == 0)
                return BadRequest("Invalid file.");

            var message = _service.SaveImage(productid, imgFile);
            return Ok(message);
        }

        [HttpGet("{productid}/image")]
        public IActionResult DownloadImage(int productid)
        {
            var imageData = _service.RestoreImage(productid);
            if (imageData == null)
                return NotFound();
            return File(imageData, "image/jpeg");
        }

        [HttpDelete("removefarmer/{farmerid}")]
        public IActionResult DeleteFarmer(int farmerid)
        {
            var result = _service.RemoveFarmer(farmerid);
            if (!result)
                return BadRequest("Failed to remove farmer.");
            return Ok("Farmer Removed Successfully");
        }

        [HttpDelete("removeproduct/{productid}")]
        public IActionResult DeleteProduct(int productid)
        {
            var result = _service.RemoveProduct(productid);
            if (!result)
                return BadRequest("Failed to remove product.");
            return Ok("Product Removed Successfully");
        }

        [HttpPut("updateproduct/{productid}")]
        public IActionResult UpdateProduct(int productid, [FromQuery] string stockitem, [FromQuery] float priceperunit, [FromQuery] int catid, [FromQuery] int quantity)
        {
            var product = _service.GetProductDetails(productid);
            if (product == null)
                return NotFound();

            var category = _service.GetCategory(catid);
            product.StockItem = stockitem;
            product.PricePerUnit =priceperunit;
            product.Category = category;
            product.Quantity = quantity;

            var result = _service.UpdateProduct(product);
            if (!result)
                return BadRequest("Failed to update product.");
            return Ok("Product Updated");
        }

        [HttpPost("updatefarmer/{farmerid}")]
        public IActionResult UpdateFarmer(int farmerid, [FromBody] Farmer farmer)
        {
            var existingFarmer = _farmerService.GetFarmerDetails(farmerid);
            if (existingFarmer == null)
                return NotFound();

            existingFarmer.Firstname = farmer.Firstname;
            existingFarmer.Lastname = farmer.Lastname;
            existingFarmer.Email = farmer.Email;
            existingFarmer.Address = farmer.Address;
            existingFarmer.PhoneNo = farmer.PhoneNo;

            var result = _service.UpdateFarmer(existingFarmer);
            if (!result)
                return BadRequest("Failed to update farmer.");
            return Ok(existingFarmer);
        }

        [HttpPost("addcategory/{category}")]
        public IActionResult AddCategory(string category)
        {
            var result = _service.SetCategory(category);
            if (!result)
                return BadRequest("Failed to add category.");
            return Ok($"New Category: {category} Added");
        }

        [HttpDelete("removecategory/{catid}")]
        public IActionResult RemoveCategory(int catid)
        {
            var result = _service.RemoveCategory(catid);
            if (!result)
                return BadRequest("Failed to remove category.");
            return Ok("Category Removed");
        }

        [HttpGet("categorylist")]
        public IActionResult GetCategoryList()
        {
            var list = _service.GetAllCategories();
            return Ok(list);
        }

        [HttpGet("allorders")]
        public IActionResult GetAllOrders()
        {
            var list = _service.GetAllOrders();
            return Ok(list);
        }

        [HttpGet("allusers")]
        public IActionResult GetAllUsers()
        {
            var list = _service.GetAllUsers();
            return Ok(list);
        }

        [HttpPost("updateuser/{userId}")]
        public IActionResult UpdateUser(int userId, [FromBody] User user)
        {
            var existingUser = _userService.GetUserDetails(userId);
            if (existingUser == null)
                return NotFound();

            existingUser.Firstname = user.Firstname;
            existingUser.Lastname = user.Lastname;
            existingUser.Email = user.Email;
            existingUser.Address = user.Address;
            existingUser.PhoneNo = user.PhoneNo;

            var result = _service.UpdateUser(existingUser);
            if (!result)
                return BadRequest("Failed to update user.");
            return Ok(existingUser);
        }

        [HttpGet("userdetails/{userId}")]
        public IActionResult GetUserDetails(int userId)
        {
            var user = _userService.GetUserDetails(userId);
            if (user == null)
                return NotFound();
            return Ok(user);
        }

        [HttpGet("image/{productName}")]
        public IActionResult DownloadImageAgain(string productName)
        {
            var imageData = _service.RestoreImageAgain(productName);
            if (imageData == null)
                return NotFound();
            return File(imageData, "image/jpeg");
        }
    }
}
