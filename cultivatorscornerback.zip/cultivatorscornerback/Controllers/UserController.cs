﻿using cultivatorscornerback.Models;
using cultivatorscornerback.Services;
using Microsoft.AspNetCore.Mvc;

using System.Collections.Generic;

namespace cultivatorscornerback.Controllers
{
    [Route("api/user")]
    [ApiController]
    [Produces("application/json")]
    public class UserController : ControllerBase
    {
        private IUserService _userService;
        private PdfExportService _pdfService;
        private EmailSenderService _mailService;

        public UserController(IUserService userService, PdfExportService pdfService, EmailSenderService mailService)
        {
            _userService = userService;
            _pdfService = pdfService;
            _mailService = mailService;
        }

        private List<CartItem> _items = new List<CartItem>();
        private Cart _myCart = new Cart();
        private User _user = new User();

        [HttpPost("register")]
        public IActionResult RegisterNewUser([FromBody] User user)
        {
            var result = _userService.Register(user);
            if (!result)
                return BadRequest("Registration failed");
            return CreatedAtAction(nameof(RegisterNewUser), new { id = user.UserId }, user);
        }

        [HttpPost("login")]
        public IActionResult LoginUser([FromBody] Authentication userID)
        {
            Console.WriteLine(userID.Email);
            var user = _userService.Authenticate(userID.Email, userID.Password);
            if (user == null)
                return Unauthorized("Invalid credentials");
            _user = user;
            _items.Clear();
            return Ok(user);
        }

        [HttpPost("addtocart/{productid}")]
        public IActionResult AddToCart(int productid, [FromQuery] int qty)
        {
            var product = _userService.AddToCart(productid, qty);
            _items.Add(product);
            return Ok(_items);
        }

        [HttpGet("checkout")]
        public IActionResult CheckOut()
        {
            double grandtotal = 0.0;
            foreach (var item in _items)
            {
                grandtotal += item.Amount;
            }
            _myCart.Items = _items;
            _myCart.GrandTotal = grandtotal;
            return Ok(_items);
        }

        [HttpPost("removefromcart/{productid}")]
        public IActionResult RemoveItem(int productid)
        {
            if (productid < 0 || productid >= _items.Count)
                return NotFound("Item not found");
            _items.RemoveAt(productid);
            return Ok(_items);
        }

        [HttpPost("placeorder")]
        public IActionResult PlaceOrder()
        {
            var result = _userService.PlaceOrder(_myCart, _user);
            if (!result)
                return BadRequest("Order placement failed");

            _pdfService.Export(_items);
            _mailService.SendEmailWithAttachment(_user.Email, "Please check below attached pdf for details. Have a good day!", "Your order is placed.", "receipt.pdf");

            _items.Clear();
            return Ok(_items);
        }

        [HttpPost("orders")]
        public IActionResult GetOrders([FromQuery] int userId)
        {
            var orders = _userService.GetOrder(userId);
            return Ok(orders);
        }
    }
}
