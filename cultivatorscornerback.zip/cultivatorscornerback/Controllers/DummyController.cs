﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace cultivatorscornerback.Controllers
{
    [Route("api/dummy")]
    [ApiController]
    public class DummyController : ControllerBase
    {
        public DummyController()
        {
            Console.WriteLine($"Constructor of {GetType().Name}");
        }

        [HttpGet]
        public ActionResult<List<int>> GetNumberList()
        {
            Console.WriteLine("Fetching number list...");
            return Ok(new List<int> { 10, 20, 30, 40, 50 });
        }
    }
}
