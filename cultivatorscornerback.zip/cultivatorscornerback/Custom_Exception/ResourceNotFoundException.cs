﻿using System;

namespace cultivatorscornerback.Custom_Exception
{
    public class ResourceNotFoundException : Exception
    {
        public ResourceNotFoundException(string message) : base(message) { }
    }
}
